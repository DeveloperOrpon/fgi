import 'package:fgi_y2j/redirectScreeen.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

Center errorWidget(){
  return const Center(child: Text("Some Thing Error Happened"));
}