// const String BASE_URL="http://173.208.242.170:9000/";
// const String BASE_URL="https://backup-rest-fgy-y2j.onrender.com/";
const String BASE_URL="https://rest.app.gobd.xyz/";
// const String BASE_URL="https://api-backup-qcpb.onrender.com/";
const String USER_LOGIN="signin";
const String USER_CREATE="signup";
const String FORGOT_PASSWORD="forgot/password";
const String VERIFY_OTP="verify/otp";
const String RESET_PASSWORD="reset-password";
const String USER_UPDATE="user/info/update";

///category
const String ALL_CATEGORIES='get/all/category';

//brand
const String ALL_BRANDS='get/all/brands';

///product
///https://rest.app.gobd.xyz/get/all/products?limit=10&page=1
const String ALL_PRODUCT='get/all/products';
const String ADD_TO_CART='add/cart/item';
const String CART_ITEMS='get/cart/user';
const String CART_REMOVE='remove/cart/item';

const String CART_UPDATE='update/cart/item';
const String UPLOAD_IMAGE='upload';
const String ORDER_CREATE='orders';
const String NOTIFICATION='notifications';