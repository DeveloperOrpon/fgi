import 'package:get/get.dart';

class FilterController extends GetxController{
  RxBool showAllBrand=RxBool(false);
  RxBool showAllCategory=RxBool(false);
  RxBool showAllSubCategory=RxBool(false);
}