List<String> loginCarouselSliderImage=[
  'assets/images/image1.png',
  'assets/images/image2.png',
  'assets/images/image3.png',
  'assets/images/image4.png',
];


List<Map<String,dynamic>> demoCategories=[
  {"name":"Burgers","url":"assets/demo/demo1.png"},
  {"name":"Hotdogs","url":"assets/demo/demo2.png"},
  {"name":"Cold drinks","url":"assets/demo/demo3.png"},
  {"name":"Buns","url":"assets/demo/demo4.png"},
  {"name":"Sauces","url":"assets/demo/demo5.png"},
  {"name":"Packages","url":"assets/demo/demo6.png"},
];


const kDefaultPadding = 20.0;